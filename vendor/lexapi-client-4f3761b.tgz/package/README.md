# @lexapi/client (TypeScript)

Official TypeScript SDK for [LexAPI](https://lex-api.com/?ref=npm-sdk) — European legal data, made queryable. EUR-Lex legislation, CJEU case law and the Official Journal behind one REST API, parsed to article level.

[![npm](https://img.shields.io/npm/v/@lexapi/client)](https://www.npmjs.com/package/@lexapi/client) · [API docs](https://lex-api.com/docs?ref=npm-sdk) · [Changelog](CHANGELOG.md)

## Install

```bash
npm install @lexapi/client
```

Node ≥ 18 (native `fetch`); the built package is also smoke-tested on Bun and Deno in CI. Zero runtime dependencies, ESM + CommonJS, strict hand-curated types. **Server-side only** — API keys are secrets and must never ship in client-side code (the SDK also skips the `User-Agent` header on browser runtimes, where setting it is forbidden).

## Quickstart

```ts
import { LexAPI } from "@lexapi/client";

const client = new LexAPI({ apiKey: "lex_..." }); // or set LEXAPI_API_KEY
const info = await client.getInfo();               // free (0 credits)
console.log(info.subscription?.tier, info.credits?.remaining);
```

Keys come from the [LexAPI dashboard](https://lex-api.com/dashboard?ref=npm-sdk) and are prefixed `lex_`.

## What each call costs

LexAPI bills a monthly credit pool ([plans](https://lex-api.com/pricing?ref=npm-sdk)). The SDK method docs repeat these:

| Credits | Calls |
| --- | --- |
| 0 | `getInfo`; webhook management and deliveries |
| 1 | `resolve`, `getCites`, `getCitedBy`, the version endpoints |
| 3 per page | `search` (`maxPages`), `getRecentDocuments` (~10 results per page) — unfetched pages refunded |
| 5 → 4 → 1 | `getDocument`, `getDocumentsBatch` (per item), `getDocumentByUrl`, `getDocumentMetadata` — 5 for a live browser fetch, settled to **4** when the Publications Office Cellar API answered, to **1** from the LexAPI corpus (`result.headers.source`); a text-unavailable answer settles at 1 |
| 5 → 1 | `extractCitations` — refunded to 1 when the document was `alreadyExtracted` |
| 5 | `semanticSearch`, `semanticLegislationSearch` (+ per live `asOf` fetch, see below) |
| 1 → 4 / 5 | `legislationAsOf` — 1 for the version alone or a provision read from the LexAPI corpus; 4 when the text is fetched (5 live from EUR-Lex), whatever the answer; 1 if the fetch fails |
| 5 | `getTransposition` — every plan |
| 15 | `semanticSearch({ hyde: true })` — refunded to 5 if HyDE falls back |
| 20 | `getCitationNetwork`, `getCitationPath`, `getRelatedDocuments`, `getCitationStats` |
| 20 | `getCounterparts` — BUSINESS, SCALE and ENTERPRISE only |
| 0 | `getNationalCoverage` (public) |
| 1 | `getNationalDocument` — every national read is a corpus read, so the 5-credit reservation always settles to 1 (an unknown id too) |
| 3 per call | `listNationalDocuments` — flat; pagination does not multiply the price |
| 5 | `nationalSemanticSearch`, `nationalLegislationSemanticSearch` — `hyde` never raises this for national case law; `asOf` adds nothing |

Failed requests refund automatically (400/403 and 5xx in full; a 404 settles at 1). Refunds land just after the response, so a response's `credits` block can still show the upfront charge. The national-law call allowance follows the same rule: a failed call (other than a 404) gives its call back too.

## Search & documents

```ts
// Structured search (POST /search)
const hits = await client.search({
  query: "artificial intelligence",
  documentType: ["communication", "guideline"],
  dateFrom: "2025-01-01",
  maxPages: 2,
});
if (hits.truncated) console.warn(hits.truncatedReason); // tier-capped pagination
if (hits.partial) console.warn(hits.partialReason);     // a page timed out — or source: "corpus"
if (hits.hint) console.log(hits.hint);                  // zero results → try semantic search
console.log(hits.headers?.searchSource, hits.headers?.searchCache); // "soap" | "cellar" | "corpus", "hit" | "miss" | "bypass"
await client.search({ query: "*", year: 2024, subdomain: "EU_CASE_LAW", fresh: true }); // filter-only, skip the 1 h cache

// Single document (POST /documentContent)
const { document, headers } = await client.getDocument({
  celexNumber: "32016R0679",
  include: ["metadata", "articles"],
  articleId: "17",
});
console.log(headers?.source); // "corpus" (1 credit) | "cellar" | "cellar-oj" (4) | "live" (5)

// Batch (POST /documentContent/batch) — per-CELEX errors don't abort the batch
const batch = await client.getDocumentsBatch({ celexNumbers: ["32016R0679", "62018CJ0311"] });
if (batch.trimmed) console.warn(`clamped to ${batch.trimmedTo}: ${batch.trimmedReason}`);
batch.errors.forEach((e) => console.warn(`${e.celex}: ${e.error}`)); // { celex, error: <message> }
console.log(batch.textUnavailable, batch.headers?.batch); // source counts — they overlap; see BatchSourceCounts

// Recent documents, metadata-only reads, URL + identifier resolution
const recent = await client.getRecentDocuments({ days: 7, documentType: "regulation" }); // one type; use search() for several
const meta = await client.getDocumentMetadata({ celexNumber: "32016R0679" });
const byUrl = await client.getDocumentByUrl({ url: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32016R0679" });
const resolved = await client.resolve("ECLI:EU:C:2020:559"); // → { celex: "62018CJ0311", resolvedVia: "ecli-corpus", verified: true }
// ELIs resolve via "eli-corpus" or "eli-cellar"; resolvedVia "eli" + verified: false = unconfirmed pattern guess, resolve again later
```

### Text availability and languages

A document can exist while EUR-Lex publishes no text for it. That is a `200` with metadata, `content: null` and a `textAvailability` verdict — billed 1 credit, not 5. **Check it before reading `content`:**

```ts
const { document } = await client.getDocument({ celexNumber: "32008R1272", language: "de" });
const ta = document.textAvailability;
if (ta && !ta.available) {
  console.log(ta.reason);              // not_in_language | not_published_yet | no_machine_readable_rendition | too_large | unknown
  console.log(ta.availableLanguages);  // null = unknown, [] = known to be none
  console.log(ta.latestConsolidated?.celex); // base acts: the consolidated version to fetch instead
}
```

`language` localizes the whole document and falls back to English (`languageRequested` / `languageFallback`). Pass `acceptLanguages: ["fr", "de"]` (or `"any"`) to get the authentic text in one call when the requested language has none. `titleLanguage` is present only when the title is not in the language you asked for.

Truncation/partial signals are always surfaced on the result (`truncated`, `partial`, `postFilteredBy`, `trimmed`/`trimmedTo`, `xWarning`) — never swallowed.

## Semantic search

```ts
// Case law (POST /search/semantic) — 5 credits
const cases = await client.semanticSearch({
  query: "transfer of personal data to third countries",
  limit: 10,
  minScore: 0.5,      // unset applies the upstream's ~0.7 relevance floor
  includeText: true,  // full text per hit instead of the default ~600-char `snippet`
});
if (cases.hint) console.warn(cases.hint); // present only on low-confidence result sets

// HyDE query rewriting — 15 credits instead of 5, ~1-3 s extra latency.
// Best-effort: on LLM failure the response reports hyde: false and the premium is refunded.
const hyde = await client.semanticSearch({ query: "credit scoring article 22", hyde: true });
console.log(hyde.hyde, hyde.hypotheticalDocument);

// Legislation (POST /legislation/semantic) — article-level matches, limit ≤ 50
const articles = await client.semanticLegislationSearch({ query: "right to be forgotten" });
for (const hit of articles.results) {
  console.log(hit.law_id, hit.article_ref, hit.score, hit.snippet);
  if (hit.consolidated) {
    // One hit per article: the consolidated text, labelled. Consolidated texts are not
    // authentic — cite hit.baseCelex (the Official Journal act); hit.baseAct is its own match.
    console.log(hit.consolidatedAsOf, hit.baseCelex, hit.consolidatedNote, hit.baseAct?.score);
  }
}
```

Persistent identity for case-law hits is `(metadata.celex_id, metadata.document_type)` — `case_id` is snapshot-scoped and does not survive index rebuilds.

EU legislation hits, `getDocument`, `getDocumentsBatch`, `getDocumentByUrl` and `getDocumentMetadata` carry the in-force label of the act when its status is known (API 2.19.0): `inForce` (today, UTC), with `notInForceReason`, `endOfValidity` or `entryIntoForce`; all absent when unknown. `semanticLegislationSearch({ inForce: true })` keeps only hits known to be in force today and reports what it removed in `inForceFilter`. Documents, snapshots and EU semantic hits also carry `provenance` and `fieldProvenance` (API 2.20.0).

### The text in force on a date (`asOf`)

```ts
const asOf = await client.semanticLegislationSearch({ query: "own funds requirements", asOf: "2019-06-01" });

console.log(asOf.asOfSummary); // { liveFetches, unresolved }
for (const hit of asOf.results) {
  if (hit.asOfResolved) {
    console.log(hit.asOfVersion);    // { celex, date, kind: "consolidated" | "as_published" }
    console.log(hit.matchedVersion); // when the text was swapped: what the index actually matched
  } else {
    console.log(hit.asOfReason);     // e.g. "not_yet_in_force", "fetch_timeout" — the hit keeps its latest text
  }
}
```

The act must be in force on that date; the version is the act as published before its first consolidation, otherwise the consolidated version in force (later versions never count). `asOf` accepts `1952-01-01` … today (UTC); an invalid date is a 400 `InvalidParamsError`, refunded in full. **Cost:** 5 for the search; each live fetch of a version the corpus doesn't hold reserves 5 and settles by outcome (Cellar 4, browser 5, no text 1, failed 0), at most 3 per request by default. A fetch your pool can't cover is skipped (`asOfReason: "insufficient_credits"`) — never a 402. `AS_OF_REASONS` lists every documented reason.

### An act on a date (`legislationAsOf`)

```ts
// POST /legislation/as-of — needs LexAPI API 2.26.0
const answer = await client.legislationAsOf({
  document: "32016R0679",
  asOf: "2019-06-01",
  provision: "art_17", // optional: an article, an annex ("anx_III") or recitals ("rct_26-28")
});

if (answer.asOfResolved) {
  console.log(answer.asOfVersion);    // { celex: "02016R0679-20160504", kind: "consolidated", date: "2016-05-04" }
  console.log(answer.provision?.text);
  if (answer.consolidated) console.log(answer.baseCelex, answer.consolidatedNote); // cite the authentic act
} else {
  console.log(answer.asOfReason);     // e.g. "not_yet_in_force" — a normal answer, not an error
}
```

For an act you already know; `semanticLegislationSearch` with `asOf` (above) is the search by meaning. The answer is the newest consolidated version dated on or before `asOf`, or the act as published in the Official Journal when none is. An answer that cannot be established is returned, not thrown: `asOfResolved: false` with an `asOfReason` and no `provision` — use a text only when `asOfResolved` is `true`. Unresolved answers are not thrown, so a `try`/`catch` never sees them: `fetch_*`, `request_deadline`, `version_list_unavailable` and `version_lookup_cap` are worth asking again; the other reasons are final for that date. Consolidated versions have no legal force; only the act as published in the Official Journal (`baseCelex`) is authentic. `document` is always the act itself; `asOfVersion.celex` (and `date`) name the version the text comes from. `asOfVersion.validUntil`, when present, is the last day that version is the answer. The answer does not say whether an individual provision applied on that date, and `act.inForceToday` is about today, not `asOf`. An unknown act is a 404 `NotFoundError`; invalid input is a 400 (`InvalidCelexError` / `InvalidParamsError`). An API older than 2.26.0 has no such endpoint and also answers 404 (`NotFoundError`). `err.unknownEndpoint` is `false` there (the API sends it from 2.27.0): check `err.message.includes("Unknown API endpoint")`. **Cost:** 1 credit when no text is fetched; when the provision's text has to be fetched, 4 (5 when it is fetched live from EUR-Lex) whatever the answer, and 1 if the fetch fails or finds no text. A fetch reserves up to 5 credits: a pool holding fewer gets `asOfReason: "insufficient_credits"`. `AS_OF_LOOKUP_REASONS` lists every documented reason.

## Citations

```ts
await client.extractCitations("32016R0679");                 // crawl + persist (idempotent)
const outbound = await client.getCites("32016R0679", { citationType: "repeal" });
const inbound = await client.getCitedBy("32008R1272", { citationType: "corrigendum" });
console.log(inbound.relationSync?.status);                     // fresh | refreshed | pending | …

for await (const page of client.paginateCitedBy("32016R0679", { limit: 200 })) {
  page.citedBy.forEach((g) => console.log(g.celexNumber, g.titleSource)); // 1 credit per page
}

const network = await client.getCitationNetwork("62018CJ0311", { limit: 100 });
if (network.partial) console.warn(network.message);   // server budget expired — network is EMPTY, not zero

const path = await client.getCitationPath("32016R0679", "31995L0046", { maxDepth: 5 });
if (!path.found) console.log(path.message);           // graceful 200, not an error

const related = await client.getRelatedDocuments("32016R0679", { limit: 10 }); // bibliographic coupling
const stats = await client.getCitationStats();

// National documents in the graph (BUSINESS, SCALE, ENTERPRISE only — 403 TierForbiddenError below that):
const withNational = await client.getCitedBy("32016R0679", { includeNational: true });
console.log(withNational.includeNational); // present once honoured; absent while no jurisdiction is live
const nationalEdges = await client.getCites("AT-NOR-10001597"); // a national id works directly, no flag needed
```

`citationType` is one of `reference`, `amendment`, `repeal`, `corrigendum`, `implementation`, `legal-basis`, `proposal`, `transposition` (`CITATION_TYPES`). All graph reads accept `language` for neighbour titles, and `includeNational` (`getCites`, `getCitedBy`, `getCitationNetwork`, `getCitationPath`, `getRelatedDocuments`, `getCitationStats`) to also return/follow national documents of live jurisdictions — BUSINESS, SCALE and ENTERPRISE only. `celexNumber` (and `getCitationPath`'s `from`/`to`) accept a national document id (e.g. `"AT-NOR-10001597"`) directly, with or without the flag; such an id whose jurisdiction isn't live is a plain `NotFoundError`.

### Provenance, filters and node identity

Every edge says where it comes from (`provenance`: `notice`, `cellar`, `notice+cellar`,
`cellar-nim`, `source`, `resolver`) and how its target was identified (`resolution`: `id`, `key`,
`abbreviation`, `text-pattern`; `null` on EUR-Lex / Cellar edges) — on `citations[]` of
`getCites` / `getCitedBy` and on `edgeDetails[]` of network neighbours. Every node carries `id`,
`jurisdiction` (`EU`, `AT`, …) and `documentKind` (`act` | `decision` | `null`) next to
`celexNumber`.

```ts
const edges = await client.getCitedBy("32016L0680", {
  citationType: ["transposition", "implementation"], // one value or a list (sent comma-separated)
  provenance: ["source", "cellar-nim"],
  jurisdictions: ["eu", "at", "de"],                  // a national code implies includeNational (BUSINESS+)
  resolution: ["id", "key"],                          // leave out abbreviation matches
});
for (const g of edges.citedBy) console.log(g.jurisdiction, g.id, g.citations?.map((c) => c.provenance));
console.log(edges.totalEdges, edges.countsSource);    // page until offset + limit >= totalEdges

const refs = await client.getCites("DE-JUD-BFH-KBRE202550123", { unresolved: true }); // national id: references with no edge
for (const r of refs.unresolved ?? []) console.log(r.kind, r.text, r.status, r.targetId);
```

`getCitationNetwork`, `getCitationPath` and `getRelatedDocuments` take the same four filters;
`getCitationNetwork` also takes `unresolved`. An unknown value is an `InvalidParamsError` with
`err.param` and `err.allowed`, refunded. `countsSource` (`stats` | `counted`, and
`paging.countsSource` on the network) says where the totals were read from; both are exact.
With `includeNational: true`, `getCitationStats` adds `byJurisdiction`, `byProvenance` and
`transposition`.

### Notified measures and counterparts

```ts
const t = await client.getTransposition("32016L0680", { jurisdictions: ["es", "cz"] }); // 5 credits, every plan
console.log(t.note); // a notification is not a finding that the measure transposes the act
for (const c of t.jurisdictions) {
  for (const m of c.measures) console.log(c.jurisdiction, m.title, m.officialJournal.date, m.id ?? "(not held)");
}
console.log(t.source.cellar?.attribution); // keep with anything you republish

const cp = await client.getCounterparts("AT-NOR-10001597"); // 20 credits, BUSINESS+
for (const v of cp.via) {
  for (const c of v.counterparts) console.log(v.euAct.id, c.rank, c.jurisdiction, c.id ?? c.title);
}
```

`getTransposition` lists the measures the member states notified to the Commission for an EU act
(CELEX sector 3), from the Publications Office's Cellar records. On BUSINESS, SCALE and ENTERPRISE,
for live jurisdictions, it also says which measures LexAPI holds (`id`, `resolved`, `resolution`,
`counts.resolved`, `source.lanes`) and adds the documents whose national source records that they
transpose or implement the act; `resolvedOnly: true` keeps only those. Otherwise those fields are
`null` (and `termsRequired: true` while the national-source terms are not accepted). A CELEX that
is not an EU act is a `NotFoundError`.

`getCounterparts` returns a national document's counterparts in the other live jurisdictions,
through the EU acts it transposes or implements, ranked `1` (the national source records it), `2`
(a notified measure LexAPI holds) or `3` (a notified measure LexAPI does not hold, `id: null`). A
lookup past the server's budget throws `TimeoutError` (503, `err.partial`), refunded. The SDK does
not retry it; retry yourself, or narrow with `jurisdictions`.

## National law

Member-state (and non-EU) legal orders alongside EUR-Lex. BUSINESS, SCALE and ENTERPRISE get full
access; FREE, STARTER and PROFESSIONAL get it within a monthly allowance of national calls. A
jurisdiction that isn't launched yet answers 404, exactly like a path that doesn't exist — check
`getNationalCoverage()` first.

```ts
const coverage = await client.getNationalCoverage(); // public, free — no allowance consumed
for (const j of coverage.jurisdictions) {
  if (j.live) console.log(j.code, j.name, j.legislation.documents, j.sources.map((s) => s.attribution));
}

const { document } = await client.getNationalDocument("AT", "AT-NOR-10001597"); // 1 credit
console.log(document.attribution); // always show this alongside the text
for (const a of document.content?.articles ?? []) console.log(a.number, a.title, a.text ?? "(no text)");

const page = await client.listNationalDocuments("AT", { q: "Datenschutz", limit: 20 }); // 3 credits flat
for await (const p of client.paginateNationalDocuments("AT", { q: "Datenschutz", limit: 100 })) {
  console.log(p.results.length, p.hasMore); // cursor paging — reaches past the first 1,000 rows, `page` doesn't
}

const hits = await client.nationalSemanticSearch("AT", { query: "Datenschutz bei Bankgeschäften" }); // 5 credits
for (const h of hits.results) console.log(h.document.documentKind, h.document.ecli, h.document.dateOfDocument);
const articles = await client.nationalLegislationSemanticSearch("DE", { query: "Kündigungsfrist" }); // 5 credits
if (articles.partial) console.warn(articles.hint); // SEARCH_INCOMPLETE: results may be missing better matches

// asOf labels each hit for a date (API 2.29.0); the texts searched and returned are today's
const dated = await client.nationalLegislationSemanticSearch("AT", { query: "Recht auf Auskunft", asOf: "2020-06-01" });
for (const h of dated.results) {
  if (h.asOfResolved) console.log(h.article_ref, h.asOfVersion?.validFrom, h.asOfVersion?.checkedAt);
  else console.log(h.article_ref, h.asOfReason); // e.g. "provision_amended_since" — today's wording, not established for the date
}
```

**National `asOf` (API 2.29.0).** The search runs over today's texts only: a provision repealed or
replaced since the date cannot be found, and the text is never swapped. A hit is resolved
(`asOfResolved: true`, `asOfVersion: { kind: "current_unit", validFrom, validTo, sourceId, checkedAt }`)
only when the publisher's dates, as of LexAPI's last recorded read of the act (`checkedAt`), show
that today's wording already applied on the date. An unresolved hit keeps today's wording; it is not
established as the text for the date (`asOfReason`, listed in `NATIONAL_AS_OF_REASONS`). LexAPI
holds such dates for Austria and Spain; elsewhere every hit is `asof_not_available`. `asOf` is a
`YYYY-MM-DD` string. `isNationalAsOfVersion(v)` tells it from the EU `asOfVersion` by `kind`.

**Incomplete national searches.** When the national index could not complete a semantic search,
results may be incomplete: with hits left the answer carries `partial: true`,
`partialReason: "SEARCH_INCOMPLETE"` and a `hint` (retry, or rephrase / change the filters). With
nothing left to return it throws instead — `NationalSemanticUnavailableError` (503,
`partialReason: "SEARCH_INCOMPLETE"`, `retryAfter` when a retry may help — retried at most once per call, and only with `retryReadOnlyPosts`) or
`NationalSemanticFilterUnreachableError` (422, not retryable as is). Both are refunded; an empty
answer would not have meant "no matches".

**One shape for every country (requires LexAPI API 2.8.0).** National documents have the same
fields, types and formats in every jurisdiction, so code written for one country works for all of
them. Every field is always present — one the source does not provide is `null` (or `[]`), never
missing:

- `documentKind` (`"act"` | `"decision"`) tells legislation from case law everywhere; `documentType`
  is the source's own label, in its language.
- `decision` — on a decision, `{ court, chamber, caseNumbers, citedNorms: [{ text, documentId }] }`,
  read server-side from whichever fields the source uses (also when the decision has no text);
  `null` for acts. `isNationalDecision(document)` narrows it.
- `content` (or `null` when there is no text — see `textAvailability`) is always
  `{ fullText, articles, textLanguages, textLanguage, embeddedForeignText, textSource, ocr, repeal, source, details }`;
  every article is `{ number, title, section, text, inForceFrom, inForceTo, details }` (`text: null`
  when the source publishes no text for that unit). What a source adds beyond these fields is under
  `content.details` / `articles[].details` — source-specific, keys differ by country.
- Semantic hits carry `document` (the listing's summary of the matched document); legislation hits
  always carry `law_title`, `article_ref`, `section`, `language`, `in_force`, `valid_from`,
  `valid_to` and `law_type`, `null` when the index has nothing.

```ts
import { isNationalDecision } from "@lexapi/client";

const { document: d } = await client.getNationalDocument("DE", "DE-JUD-BFH-KBRE202550123");
if (isNationalDecision(d)) {
  console.log(d.decision.court, d.decision.caseNumbers.join(", ")); // "BFH 3. Senat" "III R 27/24"
  for (const n of d.decision.citedNorms) console.log(n.text, n.documentId ?? "(not identified)");
}
```

A document its source withdrew (a takedown, a pseudonymisation fix) throws `DocumentWithdrawnError` (410) from `getNationalDocument` and from the citation methods for a withdrawn national id — nothing of it is served, not even the title; drop any copy you hold.

`getNationalCoverage()` also reports each live jurisdiction's `citationGraph`: its extraction
`methods` (with `unmeasured` rates and their reason codes), `edges`, the measured rates
(`decisionResolutionRate`, `actEuRate`, `textPatternRate`, `nimResolvedRate`), `transposition`,
`precision` and `floors` — `null` wherever nothing was measured. National `content` also carries
`textSource` (`html` | `pdf-text` | `ocr` | `null`) and `ocr` (engine and confidence when the text
was machine-read — never the official text).

A used-up allowance is `NationalAllowanceExhaustedError` (402); its headroom is also on
`result.headers.nationalAllowance` (`{ limit, remaining, resetsAt }`) on every admitted call from a
plan below BUSINESS.

## Webhooks

```ts
const created = await client.webhooks.create({
  name: "Chemicals compliance watch",
  url: "https://example.com/webhooks/lexapi",
  searchCriteria: { documentType: "regulation", query: "chemical*" }, // documents.new (titles)
  watchCelex: ["32006R1907", "32008R1272"],                          // watchlist.changes
});
console.log(created.webhook.secret); // returned ONLY here — store it (HMAC-SHA256 signing key)

const { webhooks } = await client.webhooks.list();             // criteriaErrors, watchCelex, deliveryCount
const detail = await client.webhooks.get(created.webhook.id);  // retryPolicy, recentDeliveries
const resumed = await client.webhooks.update(created.webhook.id, { status: "ACTIVE" });
console.log(resumed.requeuedDeliveries);
await client.webhooks.update(created.webhook.id, { searchCriteria: null }); // keep only the watch list
await client.webhooks.test(created.webhook.id);                // synchronous signed test delivery
for await (const page of client.webhooks.paginateDeliveries(created.webhook.id)) console.log(page.deliveries.length);
await client.webhooks.delete(created.webhook.id);
```

Webhooks per account: FREE 0 · STARTER 2 · PROFESSIONAL 10 · BUSINESS 50 · SCALE 100 · ENTERPRISE 100. Unsupported criteria are refused with a 400 `InvalidParamsError` whose `details` names each problem. Write calls are never retried on 5xx.

### Receiving deliveries

```ts
import { verifyWebhook } from "@lexapi/client";

// Express: keep the RAW body — the signature is over the exact bytes sent.
app.post("/webhooks/lexapi", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    const event = await verifyWebhook(req.body, req.get("x-webhook-signature"), process.env.LEXAPI_WEBHOOK_SECRET!);
    // Verified signature + 5-minute replay window. Dedupe on event.delivery?.id (stable across retries).
    if (event.event === "watchlist.changes") {
      for (const c of event.data.changes) console.log(c.watchedCelex, c.relation, c.document.celex);
    } else if (event.event === "documents.new") {
      console.log(event.data.count, event.data.totalAvailable);
    }
    res.sendStatus(200); // respond within 10 s
  } catch {
    res.sendStatus(401);
  }
});
```

`verifyWebhook` decodes the body as strict UTF-8 (one leading byte order mark is ignored) and parses it from the same bytes the signature covers; a body that is not valid UTF-8, or not one strict JSON object (no `NaN` or `Infinity`), throws `WebhookSignatureError("malformed_body")`. The error's `reason` is the first check that fails: `missing_secret`, `missing_signature` (header absent or empty), `invalid_signature`, `malformed_body`, `stale_timestamp` (a `timestamp` that is not `YYYY-MM-DDTHH:MM:SS[.fraction]` with `Z` or `±HH:MM` naming a real date and time in years 0001–9999, or further than `toleranceMs` from now; the edge passes). `toleranceMs: 0` turns the window off, a negative value rejects every delivery, and `NaN` is a `RangeError`. A secret with a lone surrogate is `missing_secret`. The header is trimmed of spaces, tabs, CR and LF only. Pass the raw bytes (`Buffer`, `Uint8Array`, `ArrayBuffer`); a string stands for its UTF-8 encoding, and a string with a lone surrogate, which has none, fails verification (`verifySignature` returns `false`, `verifyWebhook` throws `invalid_signature`, `computeSignature` throws `malformed_body`).

`verifySignature(rawBody, signature, secret)` is the signature-only check. Both use Web Crypto (constant-time comparison); an empty `secret` throws `WebhookSignatureError("missing_secret")` (a configuration error, not a bad delivery).

## Corpus export (BUSINESS, SCALE, ENTERPRISE)

`export()` streams NDJSON rows via the fetch body stream — constant memory regardless of result size. BUSINESS, SCALE and ENTERPRISE only; lower tiers get a 403 `TierForbiddenError`.

**Billing (credit plans, API 2.3.0):** 1 credit per row written, at least 1 per export. The call is admitted for 1 credit, the matching rows are counted, and the rest of 1 credit per row it can return is reserved; a pool that cannot cover it throws `CreditsExhaustedError` before anything streams. Unwritten rows are refunded when the stream ends: `stream.done?.credits?.charged`.

**Filters:** `documentType` matches the stored label exactly, ignoring case; `documentTypeCode: "regulation"` selects the family (incl. implementing and delegated regulations); `author` matches whole values; `dateFrom` / `dateTo` are `YYYY-MM-DD`; `changedSince` returns rows whose text changed (the cheapest incremental sync) and `fetchedSince` rows written to at all — both an ISO date or a date-time with a timezone, or a `Date`; `limit` is a positive integer (anything else throws `RangeError`).

Licensing: exported content may not be used to train or evaluate ML models without a separate licence ([Terms §6](https://lex-api.com/terms?ref=npm-sdk#acceptable-use)). For training data, [Arieta Data](https://data.arietalabs.com/?ref=npm-sdk), a sister product from Arieta Labs, licenses datasets drawn from the same corpus for training, retrieval and evaluation.

```ts
const stream = await client.export({ documentTypeCode: "regulation", dateFrom: "2024-01-01", limit: 10_000 });

console.log(stream.meta?.totalMatching, stream.headers.total); // leading _meta envelope / X-Export-Total

for await (const row of stream) {
  process(row.celex, row.documentTypeCode, row.parsedContent);
}

console.log(stream.done?.written, stream.done?.skippedStubs);
if (stream.truncated) console.warn(`rows not reached (${stream.done?.truncatedBy}) — narrow filters or resume via changedSince`);
```

The `_meta`/`_done` envelope lines are never yielded as rows; the stream is single-pass (re-iterating a fully read stream yields nothing; iterating one you ended early raises `IncompleteExportError` — call `export()` again to re-read). Breaking out of the loop (or `stream.cancel()`, or the call's `signal`) releases the connection. **A stream that ends without its `_done` trailer throws `IncompleteExportError`** (so does a `_done` with `complete: false`, or an `_error` line, which is never yielded as a row) after yielding the rows that did arrive — the server stopped mid-export and they are not the whole set (`stream.complete` stays `false`; `stream.rowsRead` counts them). A dropped connection throws `NetworkError`, a stall longer than `timeoutMs` throws `TimeoutError`. A line ends at a line feed byte; lines are read as strict UTF-8 whatever charset the response names (one byte order mark at the very start of the stream is ignored) and trimmed of spaces, tabs and CR; lines that are not UTF-8, or not one JSON object, are counted in `stream.invalidLines`, and blank lines are skipped. `stream.meta` comes only from the very first line. For "did matching rows remain that this export did not reach?" read `stream.truncated` — after iterating it is the server's authoritative `_done.truncated` (`stream.done?.truncatedBy`: `limit`, `max_rows`, `credits` or `recovered`); before that, a hint from the up-front count, and `false` when nothing says. Metadata-only rows are skipped unless `includeStubs: true`.

## Point-in-time versions

Versions are LexAPI's fetch snapshots — the document as LexAPI fetched it — not the law in force on a date; history begins at first ingestion. (For the version of an EU act for a date, use `legislationAsOf`.)

```ts
import { NotFoundError } from "@lexapi/client";

const history = await client.listDocumentVersions("32016R0679");
console.log(history.currentVersion, history.trackedSince);

const snapshot = await client.getDocumentVersion("32016R0679", 2);
console.log(snapshot.document.parsedContent, snapshot.corpusVersion);

try {
  const atDate = await client.getDocumentAtDate("32016R0679", "2026-04-01");
  console.log(atDate.kind);                   // "observation_snapshot" — not the law in force on that date
  console.log(atDate.document.observedFrom);  // when this version began in LexAPI's fetch history (null: no record of it)
  console.log(atDate.document.observedUntil); // when the next version's text arrived (null: current version)
  if (atDate.inForceLookup) console.log("for the act on a date, use legislationAsOf");
} catch (err) {
  if (err instanceof NotFoundError && err.beforeTracking) console.log(err.trackedSince); // tracking began later
  else if (err instanceof NotFoundError && err.boundaryUnknown) console.log(err.candidates); // read them with getDocumentVersion
  else throw err;
}
```

`fetchedAt` is when a version's text arrived at LexAPI; `observedFrom` is when the version began in LexAPI's fetch history, `null` when LexAPI has no record of it — then `fetchedAt` is the last fetch of its text, not when the version began. A future date returns the current version with `dateInFuture: true` (and `xWarning`). Each call costs 1 credit; a `boundaryUnknown` 404 is refunded. A date before the document entered the corpus rejects with `NotFoundError` (`beforeTracking`, `trackedSince`); a date next to a version stored before API 2.28.0 whose start LexAPI has no record of rejects with `boundaryUnknown` and `candidates` (`{ version, fetchedAt, observedFrom }`, at most 10, `candidatesTruncated` beyond; `[]` when none).

## Response headers

Every JSON result carries `headers` — the LexAPI response headers, parsed:

```ts
const r = await client.getDocument({ celexNumber: "32016R0679" });
r.headers?.source;            // X-Source: corpus | cellar | cellar-oj | live
r.headers?.rateLimit;         // { limit, remaining, reset (seconds), policy }
r.headers?.languageFallback;  // X-Language-Fallback
r.headers?.textAvailable;     // X-Text-Available
r.headers?.corpusVersion;     // X-Corpus-Version
```

Also: `searchSource`, `searchCache`, `warning`, `ignoredDocumentTypes`, `postFilteredBy`, `documentTypeFanOut`, `batch`. The older `xWarning` (and `corpusVersion` on version responses) are still set.

On the four national document/semantic endpoints, `headers.nationalAllowance` (`{ limit, remaining, resetsAt }`, from `X-National-Limit`/`X-National-Remaining`/`X-National-Reset`) reports the monthly national-call allowance left — present only for FREE/STARTER/PROFESSIONAL callers (absent for BUSINESS and above, and for `getNationalCoverage`).

## Configuration

```ts
const client = new LexAPI({
  apiKey: "lex_...",                     // or LEXAPI_API_KEY env var
  baseUrl: "https://lex-api.com/api/v1", // default
  timeoutMs: 95_000,                     // per attempt, incl. the body; per-call: client.getInfo({ timeoutMs: 5_000 })
  retry: { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30_000, retryReadOnlyPosts: false },
  fetch: myFetch,                        // injectable transport (testing / polyfills)
  userAgentSuffix: "my-app/1.0",         // appended to `lexapi-typescript/<version>`
});
```

Redirects are followed only within the origin of `baseUrl` (or to the same host over HTTPS on the default ports), at most five per attempt; any other redirect is refused with a `NetworkError`, so the API key is never sent to another origin. A custom `fetch` must honour `redirect: "manual"` for this to hold.

## Retries, timeouts and cancellation

The SDK retries automatically **only when a retry cannot charge you twice** (the shared SDK contract, [§1.2](https://github.com/Lex-API/lexapi-typescript/blob/main/docs/sdk-contract.md)). Up to 3 retries (`retry.maxRetries`), exponential backoff with full jitter (base 0.5 s, cap 30 s):

| Failure | GET, billed | GET, free (`getInfo`, webhook reads) | Read-only POST | Mutating call |
|---|---|---|---|---|
| 429, not a quota | retry | retry | retry | retry |
| 429 reporting an exhausted quota (`RateLimitedError.quotaExhausted`) | no | no | no | no |
| Never reached the server (DNS failure, connection refused/unreachable, connect timeout, TLS handshake failure; Cloudflare 521/522/523) | retry | retry | retry | retry |
| App-origin 502 / 503 / 504 | retry | retry | only with `retry: { retryReadOnlyPosts: true }` | no |
| Proxy-origin 502 / 503 / 504, 520, 524 | no | retry | no | no |
| Any other transport error (reset, connection closed — `fetch` cannot tell before-response from mid-response — read error, `REQUEST_TIMEOUT`) | no | retry | no | no |
| 400 / 401 / 402 / 403 / 404 / 500 and anything else | no | no | no | no |

- **Read-only POSTs** are `search`, `getDocument`, `getDocumentsBatch`, `getDocumentByUrl`, `getDocumentMetadata`, `resolve`, `semanticSearch`, `semanticLegislationSearch`, `legislationAsOf`, `nationalSemanticSearch`, `nationalLegislationSemanticSearch`. **Mutating calls** are the webhook writes and `extractCitations` (it persists edges).
- **App-origin** = the response carries a non-empty `X-LexAPI-Version` header or a `RateLimit-Limit` header (the API's rate limiter sets `RateLimit-*` on every billable app response; proxies never do). A JSON error body alone is not enough. Anything else is treated as a proxy answer: the API may have charged the call and not refunded it, so a billed call is not retried.
- **Wait:** `Retry-After` on any status (decimal seconds such as `5` or `2.5`, or an HTTP-date in one of the three RFC 9110 forms with `GMT`, `UTC` or `+0000`; anything else counts as absent); on a 429 only, then `RateLimit-Reset` (decimal seconds) and the JSON `retryAfter` field (a number ≥ 0, else absent; the top-level field first, then the one in `details`); on a 503 `NATIONAL_SEMANTIC_UNAVAILABLE` (an incomplete national search), the JSON `retryAfter` field. `X-RateLimit-*` is not read. Every hint is clamped to the 30 s cap (`retry.maxDelayMs`; a cap below the server's requested wait shortens it); numbers above 1e12 / 1e9 are read as epoch ms / s. A quota 429 has `retryAfter: undefined`. An incomplete national search whose only hint is unusable is not retried. No wait is longer than 2^31−1 ms (about 24.8 days), whatever `maxDelayMs` says: a longer timer would fire at once.

**Timeout:** `timeoutMs` (default 95 s) is an *inactivity* limit per attempt: the longest the SDK waits for the next bytes — until the response head, then between body chunks (the timer restarts on every chunk), for JSON bodies and export streams alike. It is not a deadline for the whole call. On expiry you get `TimeoutError` with `code: "REQUEST_TIMEOUT"` (status 0). `fetch` cannot time the connect phase separately, so it counts inside the first window. The 95 s default sits above the API's 90 s deadline on document reads, so that timeout comes back as a typed, refunded 504; the CDN ends any wait at 100 s. `timeoutMs: Infinity` sets no limit, and `0` times out at once (on an export stream's body reads, `0` sets no idle limit); a value above 2^31−1 ms is clamped to that.

**Iterators:** `paginateCites`, `paginateCitedBy`, `webhooks.paginateDeliveries` and `paginateNationalDocuments` yield each page as it arrives and end by the documented stop conditions (a short or empty page, `totalEdges` / `total` reached, no `nextCursor`, `hasMore` not `true`, a page without its list). They throw `InvalidResponseError` when the server stops advancing: a cites/cited-by page echoing an `offset` other than the one requested; a `nextCursor` already sent in the walk; and, only when the answers carry no usable `totalEdges`/`offset` (cites, cited-by) or `total` (deliveries), three pages in a row that repeat the one before (cites, cited-by: the same list; deliveries: no unseen `id`); a page with such a signal ends a run (on cites/cited-by its list is still the one the next page is compared with). A national `nextCursor` that is not a string throws too. When a walk throws, the pages already yielded stay valid; the page that showed the stall is not yielded and is on `err.body`. A starting `offset` that is not an integer ≥ 0, or a `limit` that is not an integer ≥ 1 (each at most 2^53 − 1), is a `RangeError` before any request (every iterator, `paginateNationalDocuments` included). Cites/cited-by advance by each group's `citationCount`; a group whose count is 0 but whose edge list is not empty counts its list.

**Cancellation:** every method takes `{ signal }`. Aborting cancels the in-flight request, any retry wait and an export stream (the connection is released), and rejects with `RequestAbortedError` (`code: "ABORTED"`, `cause` = the signal's reason).

```ts
const controller = new AbortController();
req.on("close", () => controller.abort());
await client.semanticSearch({ query: "gdpr" }, { signal: controller.signal });
```

## Typed errors

Every non-2xx response maps to a typed error carrying `code`, `status`, `message`, `details`, `retryAfter`, the raw `body` and parsed `headers`:

```ts
import { CreditsExhaustedError, NotFoundError, PaymentPastDueError, RateLimitedError, TierForbiddenError } from "@lexapi/client";

try {
  await client.semanticSearch({ query: "gdpr" });
} catch (err) {
  if (err instanceof RateLimitedError && err.quotaExhausted) console.log(`legacy quota resets ${err.resetsAt}`);
  else if (err instanceof RateLimitedError) console.log(`retry in ${err.retryAfter}s`, err.rateLimit);
  else if (err instanceof CreditsExhaustedError) console.log(`need ${err.weight}, have ${err.available}; resets ${err.resetsAt}`);
  else if (err instanceof PaymentPastDueError) console.log(`pay the open invoice: ${err.billingUrl ?? "in the dashboard"}`); // before TierForbiddenError: it extends it
  else if (err instanceof TierForbiddenError) console.log((err.body as { upgradeUrl?: string })?.upgradeUrl);
  else if (err instanceof NotFoundError) console.log(err.unknownEndpoint || err.message.includes("Unknown API endpoint") ? "no such endpoint" : "no such document");
  else throw err;
}
```

| Class | `code` | HTTP |
| --- | --- | --- |
| `NotFoundError` | `NOT_FOUND` | 404 — `.unknownEndpoint` is `true` when the API (2.27.0 or later) has no such endpoint: a mistyped path, a method newer than the API, or a national route for a country that is not available. Always `false` on APIs before 2.27.0; there the message contains "Unknown API endpoint". `.reason` is `details.reason`; on `getDocumentAtDate` (API 2.28.0) `.beforeTracking` (with `.trackedSince`, `.inForceLookup`) or `.boundaryUnknown` (with `.candidates`, `.candidatesTruncated`). |
| `DocumentWithdrawnError` | `DOCUMENT_WITHDRAWN` | 410 — a national document its source withdrew; nothing of it is served; `.id`/`.jurisdiction`/`.withdrawnAt`; not retryable, drop any copy you hold |
| `InvalidCelexError` / `InvalidUrlError` / `InvalidParamsError` | `INVALID_CELEX` / `INVALID_URL` / `INVALID_PARAMS` | 400 — `InvalidParamsError.param` / `.value` / `.allowed` name a refused filter, the value sent and the allowed values |
| `AuthenticationError` | `UNAUTHORIZED` (derived) | 401 |
| `CreditsExhaustedError` | `CREDITS_EXHAUSTED` | 402 |
| `NationalAllowanceExhaustedError` | `NATIONAL_ALLOWANCE_EXHAUSTED` | 402 — FREE/STARTER/PROFESSIONAL's monthly national-law call allowance is used up; `resetsAt`/`limit`/`upgradeUrl` |
| `NationalSemanticNotEnabledError` | `NATIONAL_SEMANTIC_NOT_ENABLED` | 409 — this jurisdiction has no semantic index to search; `.jurisdiction`; not retryable, refunded |
| `TierForbiddenError` | `TIER_FORBIDDEN` | 403 |
| `PaymentPastDueError` (extends `TierForbiddenError`) | `PAYMENT_PAST_DUE` | 403 — a subscription payment failed and was not completed in time; API requests are refused until the payment succeeds; pay the open invoice in the dashboard (`.billingUrl`; `.accessEndedAt` when known); not retryable. Before API 2.27.0 a failed payment was refused at once with a 403 without a code, raised as `TierForbiddenError`. |
| `RateLimitedError` | `RATE_LIMITED`, `QUOTA_EXHAUSTED` | 429 — `QUOTA_EXHAUSTED` (legacy plans' used-up quota) is never retried; `resetsAt` says when it refills |
| `InternalServerError` | `INTERNAL` | 500 |
| `UpstreamError` | `UPSTREAM_ERROR` | 502; Cloudflare 520–523 |
| `ServiceUnavailableError` | `SERVICE_UNAVAILABLE` (derived) | 503 |
| `NationalSemanticUnavailableError` (extends `ServiceUnavailableError`) | `NATIONAL_SEMANTIC_UNAVAILABLE` | 503 — a jurisdiction's semantic index is temporarily unreachable, or could not complete this search with nothing left to return (`.partialReason === "SEARCH_INCOMPLETE"`, `retryAfter` — absent once the same search has repeatedly come back incomplete, and then not retried); `.jurisdiction`; retry later |
| `NationalSemanticFilterUnreachableError` (extends `InvalidParamsError`) | `NATIONAL_SEMANTIC_FILTER_UNREACHABLE` | 422 — the national index cannot search this slice (jurisdiction, document kind, filters) completely and there is nothing left to return; a coverage limit, not a malformed request (the request may be valid; `.param` is absent); `.jurisdiction`, `.partialReason`; not retryable as is — rephrase the query or change the filters; refunded |
| `TimeoutError` | `TIMEOUT` (504, 524; 503 from `getCounterparts`, with `.partial` / `.serverTimeoutMs`) / `REQUEST_TIMEOUT` (status 0, the SDK's own timeout) | |
| `NetworkError` | `CONNECTION_ERROR` | 0 (transport failure, or the connection dropped — incl. mid-export) |
| `RequestAbortedError` | `ABORTED` | 0 (your `signal` fired) |
| `InvalidResponseError` | `INVALID_RESPONSE` | a 2xx that is not the documented shape: no body, a body that is not JSON (e.g. a proxy HTML page), JSON that is not an object, `success: false`, a list such as `results` that is missing where the endpoint always sends it, is not a list, or holds items that are not objects, or an object such as `document` that is missing or not an object. Never read as an empty result; unknown extra fields are accepted. The message never quotes the body. |
| `IncompleteExportError` | `INCOMPLETE_EXPORT` | 0 — an export ended without a complete `_done` trailer, or the server sent an `_error` line (`rowsRead`, `details`) |
| `LexAPIError` (base) | `INTERNAL` | any other status (e.g. 409, 413), with `status` kept |

`PaymentPastDueError` extends `TierForbiddenError`, so a handler for `TierForbiddenError` still catches a failed payment, as it did before API 2.27.0. To tell the two apart, check `PaymentPastDueError` (or `err.code === "PAYMENT_PAST_DUE"`) first.

**Response text on errors.** No error message quotes the response body. For a body that is not JSON, the first 200 characters (code points) are on `err.bodyExcerpt`; for an `InvalidResponseError` about JSON of the wrong shape, the parsed value is on `err.body`. Both are raw response content that may contain document text: do not show them to a model or log them by default. Neither is an own property of the error (both are read through getters), so `console.log(err)`, `util.inspect(err)` and `JSON.stringify(err)` leave them out. A `2xx` answer with `success: false` and an API error in its body throws that error (e.g. `NotFoundError`) with the `2xx` status.

**`instanceof` across builds.** The package ships an ESM and a CommonJS build; in a process that loads both (a CommonJS dependency wrapping the SDK inside an ESM app, Next.js, …) they are two copies of every class. The error classes carry a shared brand (`Symbol.for`), so `err instanceof NotFoundError` is still true for an error thrown by the other copy. `isLexAPIError(err)` / `isLexAPIError(err, NotFoundError)` does the same as a function.

Both the typed envelope (`{success: false, error: {code, message, details}}`) and the legacy bare `{error, message, details?}` shape (still used by 429s, API-key 401s, `/search` and webhook validation, the export tier gate and semantic upstream errors) are parsed; unknown codes stay on the base `LexAPIError` with the raw code string.

## Credit visibility

Every response keeps its raw `usage` / `credits` blocks; `getCreditUsage` normalizes them:

```ts
import { getCreditUsage } from "@lexapi/client";

const { unitsCharged, creditsRemaining, resetsAt } = getCreditUsage(await client.getInfo());
```

`unitsCharged` maps `credits.operation_weight` (0 for free ops like `/info`); `creditsRemaining` falls back to `usage.remaining` on legacy daily-call accounts.

## Development

```bash
npm ci
npm run lint        # tsc --noEmit (strict)
npm test            # vitest (Node ≥ 20)
npm run build       # tsup -> dist/ (ESM + CJS + d.ts / d.cts)
npm run smoke:dist  # framework-free check of the built bundles (runs on Node 18+)
```

See [docs/sdk-contract.md](https://github.com/Lex-API/lexapi-typescript/blob/main/docs/sdk-contract.md) for the SDK contract. Docs: <https://lex-api.com/docs?ref=npm-sdk>
